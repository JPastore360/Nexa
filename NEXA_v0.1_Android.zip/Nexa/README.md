# NEXA

**Sua rotina mais inteligente.**

Protótipo Android nativo da NEXA, uma central pessoal com agenda, tarefas, assistente de IA e integrações.

## NEXA v0.1
- Início / Meu Dia
- Agenda diária
- Assistente com interface reativa
- Central de integrações
- Tarefas
- Identidade visual grafite + verde esmeralda
- Brasão NEXA no launcher
- GitHub Actions para gerar APK

> As integrações externas estão visualmente preparadas, mas não são marcadas como conectadas até autenticação real.

## Compilar
Abra no Android Studio e execute o módulo `app`, ou use a Action `Build NEXA APK` no GitHub.
