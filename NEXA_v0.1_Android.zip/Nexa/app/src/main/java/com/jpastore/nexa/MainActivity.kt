package com.jpastore.nexa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF06110E)
private val Surface = Color(0xFF0C1C1A)
private val Surface2 = Color(0xFF102522)
private val Green = Color(0xFF00E889)
private val Mint = Color(0xFF74FFC0)
private val Muted = Color(0xFF8DA6A0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexaTheme { NexaApp() } }
    }
}

@Composable
fun NexaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Green, secondary = Mint, background = Bg,
            surface = Surface, onBackground = Color.White, onSurface = Color.White
        ),
        typography = Typography(),
        content = content
    )
}

enum class Tab(val title: String, val icon: ImageVector) {
    Inicio("Início", Icons.Default.Home),
    Agenda("Agenda", Icons.Default.CalendarMonth),
    Nexa("NEXA", Icons.Default.AutoAwesome),
    Central("Central", Icons.Default.GridView),
    Tarefas("Tarefas", Icons.Default.CheckCircle)
}

@Composable
fun NexaApp() {
    var tab by remember { mutableStateOf(Tab.Inicio) }
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF071512)) {
                Tab.entries.forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = {
                            if (item == Tab.Nexa) {
                                Box(
                                    Modifier.size(48.dp).background(
                                        Brush.radialGradient(listOf(Green, Color(0xFF063E2B))),
                                        CircleShape
                                    ), contentAlignment = Alignment.Center
                                ) { Icon(item.icon, null, tint = Color.White) }
                            } else Icon(item.icon, null)
                        },
                        label = { Text(item.title, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Green, selectedTextColor = Green,
                            unselectedIconColor = Muted, unselectedTextColor = Muted,
                            indicatorColor = Color.Transparent
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when(tab) {
                Tab.Inicio -> HomeScreen { tab = it }
                Tab.Agenda -> AgendaScreen()
                Tab.Nexa -> NexaScreen()
                Tab.Central -> CentralScreen()
                Tab.Tarefas -> TasksScreen()
            }
        }
    }
}

@Composable
fun ScreenHeader(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            NexaMark(34)
            Spacer(Modifier.width(12.dp))
            Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.Settings, null, tint = Muted)
        }
        subtitle?.let { Text(it, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
    }
}

@Composable
fun NexaMark(size: Int = 42) {
    Box(
        Modifier.size(size.dp).background(
            Brush.linearGradient(listOf(Color(0xFF004E36), Green)),
            RoundedCornerShape((size/3).dp)
        ),
        contentAlignment = Alignment.Center
    ) { Text("N", fontWeight = FontWeight.Black, color = Color.White, fontSize = (size/2).sp) }
}

@Composable
fun HomeScreen(go: (Tab)->Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            ScreenHeader("NEXA")
            Column(Modifier.padding(horizontal = 20.dp)) {
                Text("Boa noite,", color = Muted, fontSize = 17.sp)
                Text("Júlio! 👋", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("Sua rotina, organizada em um só lugar.", color = Muted)
                Spacer(Modifier.height(18.dp))
                CardBlock {
                    Text("NEXA INSIGHT", color = Green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Você está em dia. Posso organizar seus próximos compromissos e prioridades.", fontSize = 16.sp)
                }
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Metric("3", "Tarefas", Icons.Default.CheckCircle, Modifier.weight(1f))
                    Metric("2", "Agenda", Icons.Default.CalendarMonth, Modifier.weight(1f))
                    Metric("0", "Alertas", Icons.Default.Notifications, Modifier.weight(1f))
                }
                Spacer(Modifier.height(22.dp))
                Text("Próximos compromissos", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                EventCard("20:00", "Revisar relatórios", "Trabalho", Green)
                EventCard("21:00", "Estudos • Agronomia", "Faculdade", Color(0xFF62A5FF))
                Spacer(Modifier.height(18.dp))
                Text("Acesso rápido", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Quick("Falar com a Nexa", Icons.Default.Mic, {go(Tab.Nexa)}, Modifier.weight(1f))
                    Quick("Abrir agenda", Icons.Default.CalendarMonth, {go(Tab.Agenda)}, Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
fun CardBlock(content: @Composable ColumnScope.()->Unit) =
    Surface(color = Surface2, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), content = content)
    }

@Composable
fun Metric(value:String, label:String, icon:ImageVector, modifier:Modifier) {
    Surface(color=Surface, shape=RoundedCornerShape(18.dp), modifier=modifier) {
        Column(Modifier.padding(14.dp), horizontalAlignment=Alignment.CenterHorizontally) {
            Icon(icon,null,tint=Green); Text(value,fontSize=22.sp,fontWeight=FontWeight.Bold)
            Text(label,color=Muted,fontSize=11.sp)
        }
    }
}

@Composable
fun EventCard(time:String, title:String, group:String, accent:Color) {
    Surface(color=Surface, shape=RoundedCornerShape(18.dp), modifier=Modifier.fillMaxWidth().padding(bottom=9.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.width(4.dp).height(42.dp).background(accent, CircleShape))
            Spacer(Modifier.width(12.dp))
            Text(time, color=Muted, modifier=Modifier.width(52.dp))
            Column { Text(title,fontWeight=FontWeight.SemiBold); Text(group,color=Muted,fontSize=12.sp) }
        }
    }
}

@Composable
fun Quick(title:String, icon:ImageVector, click:()->Unit, modifier:Modifier) {
    Surface(color=Surface2, shape=RoundedCornerShape(18.dp), modifier=modifier.clickable(onClick=click)) {
        Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
            Icon(icon,null,tint=Green); Spacer(Modifier.width(10.dp)); Text(title,fontSize=13.sp)
        }
    }
}

@Composable
fun AgendaScreen() {
    Column {
        ScreenHeader("Agenda", "Dia • Semana • Mês")
        Row(Modifier.padding(horizontal=20.dp), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            listOf("Dia","Semana","Mês").forEachIndexed { i,s ->
                Surface(color=if(i==0) Green else Surface, shape=RoundedCornerShape(14.dp)) {
                    Text(s, color=if(i==0) Bg else Muted, modifier=Modifier.padding(horizontal=18.dp,vertical=9.dp))
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Column(Modifier.padding(horizontal=20.dp)) {
            Text("Quinta, 17 de Setembro", fontSize=18.sp,fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            EventCard("08:00","Treinamento de Operação","Trabalho",Green)
            EventCard("10:00","Reunião de equipe","Trabalho",Color(0xFF62A5FF))
            EventCard("14:00","Estudos • Agronomia","Faculdade",Green)
            EventCard("20:00","Revisar relatórios","Trabalho",Color(0xFFFF5B62))
        }
    }
}

@Composable
fun NexaScreen() {
    var listening by remember { mutableStateOf(false) }
    val infinite = rememberInfiniteTransition(label="pulse")
    val pulse by infinite.animateFloat(
        initialValue=0.88f, targetValue=1.12f,
        animationSpec=infiniteRepeatable(tween(if(listening) 650 else 1600), RepeatMode.Reverse), label="p"
    )
    Column(Modifier.fillMaxSize(), horizontalAlignment=Alignment.CenterHorizontally) {
        ScreenHeader("NEXA", if(listening) "Ouvindo você…" else "Como posso te ajudar hoje?")
        Spacer(Modifier.height(20.dp))
        Box(Modifier.size(230.dp), contentAlignment=Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val r=size.minDimension/2
                drawCircle(Green.copy(alpha=.06f), radius=r*pulse)
                drawCircle(Green.copy(alpha=.12f), radius=r*.78f*pulse)
                drawCircle(Green.copy(alpha=.28f), radius=r*.55f*pulse, style=androidx.compose.ui.graphics.drawscope.Stroke(3f))
                for(i in 0..28) {
                    val x=size.width*i/28f
                    val h=(10 + (i%7)*5)*pulse
                    drawLine(Green.copy(alpha=.7f), Offset(x, center.y-h), Offset(x, center.y+h), 2f)
                }
            }
            Box(Modifier.size(112.dp).background(Brush.radialGradient(listOf(Green,Color(0xFF003A29))),CircleShape),
                contentAlignment=Alignment.Center) {
                Text("N",fontSize=52.sp,fontWeight=FontWeight.Black)
            }
        }
        Text(if(listening) "Pode falar…" else "Toque no núcleo para conversar", color=if(listening) Green else Muted)
        Spacer(Modifier.height(22.dp))
        Surface(color=Surface2, shape=RoundedCornerShape(24.dp),
            modifier=Modifier.padding(horizontal=28.dp).fillMaxWidth().clickable{listening=!listening}) {
            Row(Modifier.padding(17.dp), horizontalArrangement=Arrangement.Center, verticalAlignment=Alignment.CenterVertically) {
                Icon(if(listening) Icons.Default.Stop else Icons.Default.Mic,null,tint=Green)
                Spacer(Modifier.width(10.dp)); Text(if(listening) "Encerrar escuta" else "Falar com a Nexa",fontWeight=FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.padding(horizontal=20.dp), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            listOf("Resumir meu dia","Criar tarefa","Ver agenda").forEach {
                AssistChip(onClick={}, label={Text(it,fontSize=11.sp)})
            }
        }
    }
}

data class Integration(val name:String,val icon:ImageVector,val status:String)
@Composable
fun CentralScreen() {
    val data=listOf(
        Integration("Gmail",Icons.Default.Email,"Conectar"),
        Integration("Google Calendar",Icons.Default.CalendarMonth,"Conectar"),
        Integration("WhatsApp",Icons.Default.Chat,"Conectar"),
        Integration("Instagram",Icons.Default.PhotoCamera,"Conectar"),
        Integration("Facebook",Icons.Default.Public,"Conectar"),
        Integration("ChatGPT",Icons.Default.AutoAwesome,"Configurar")
    )
    LazyColumn {
        item { ScreenHeader("Central","Suas contas e serviços em um só lugar") }
        items(data.chunked(2)) { row ->
            Row(Modifier.padding(horizontal=20.dp,vertical=6.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                row.forEach { item ->
                    Surface(color=Surface,shape=RoundedCornerShape(20.dp),modifier=Modifier.weight(1f)) {
                        Column(Modifier.padding(18.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                            Icon(item.icon,null,tint=Green,modifier=Modifier.size(32.dp))
                            Spacer(Modifier.height(10.dp)); Text(item.name,fontWeight=FontWeight.Bold,fontSize=13.sp)
                            Text(item.status,color=Green,fontSize=11.sp)
                        }
                    }
                }
                if(row.size==1) Spacer(Modifier.weight(1f))
            }
        }
        item {
            CardBlock {
                Text("MULTI-CONTA",color=Green,fontSize=11.sp,fontWeight=FontWeight.Bold)
                Text("Preparada para e-mail pessoal, corporativo e outras contas.",modifier=Modifier.padding(top=8.dp))
            }
        }
    }
}

data class TaskItem(val title:String,val group:String,val done:Boolean)
@Composable
fun TasksScreen() {
    var tasks by remember { mutableStateOf(listOf(
        TaskItem("Revisar relatórios operacionais","Trabalho",false),
        TaskItem("Estudar química do solo","Agronomia",true),
        TaskItem("Praticar inglês","Pessoal",false),
        TaskItem("Planejar publicações LinkedIn","Conteúdo",false),
        TaskItem("Academia","Pessoal",true)
    )) }
    LazyColumn {
        item { ScreenHeader("Tarefas","Foco no que realmente importa") }
        items(tasks.indices.toList()) { i ->
            val t=tasks[i]
            Surface(color=Surface,shape=RoundedCornerShape(18.dp),modifier=Modifier.padding(horizontal=20.dp,vertical=5.dp).fillMaxWidth()) {
                Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically) {
                    Checkbox(checked=t.done,onCheckedChange={v -> tasks=tasks.toMutableList().also{it[i]=t.copy(done=v)}})
                    Column(Modifier.padding(start=8.dp)) {
                        Text(t.title,fontWeight=FontWeight.SemiBold)
                        Text(t.group,color=Muted,fontSize=12.sp)
                    }
                }
            }
        }
    }
}
